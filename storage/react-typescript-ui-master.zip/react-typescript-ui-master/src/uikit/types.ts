export type TSorting = {
  value: string;
  label: string;
};
