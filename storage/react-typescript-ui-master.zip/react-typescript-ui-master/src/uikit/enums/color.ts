export enum ETextColor {
  Light = "light",
  Dark = "dark",
}

export enum EColorType {
  Icon = "icon",
  Text = "text",
}
