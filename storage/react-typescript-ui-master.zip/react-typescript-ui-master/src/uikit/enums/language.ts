export enum ELanguages {
  Ru = "RU",
  En = "EN",
}
