export enum ETheme {
  Dark = "DARK",
  Light = "LIGHT",
}
