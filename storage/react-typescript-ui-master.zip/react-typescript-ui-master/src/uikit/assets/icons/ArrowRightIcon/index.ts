export * from "./ArrowRightIcon";
