export * from "./SpinnerIcon";
