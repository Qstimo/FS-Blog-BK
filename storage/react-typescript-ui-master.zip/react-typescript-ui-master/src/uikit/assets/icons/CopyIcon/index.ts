export * from "./CopyIcon";
