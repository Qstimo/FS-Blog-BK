import type { SVGProps } from "react";

export type TIconProps = SVGProps<SVGSVGElement>;
