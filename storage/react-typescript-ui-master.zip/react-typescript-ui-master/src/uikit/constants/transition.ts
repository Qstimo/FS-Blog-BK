export const DEBOUNCE_TIMEOUT = 300;
export const TRANSITION = 300;
