export const FORMAT_DATE = "dd.MM.yyyy";
