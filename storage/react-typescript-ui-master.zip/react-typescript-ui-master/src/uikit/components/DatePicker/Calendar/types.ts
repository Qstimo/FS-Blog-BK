type TCalendarValuePiece = Date | null;

export type TCalendarValue = TCalendarValuePiece | [TCalendarValuePiece, TCalendarValuePiece];
