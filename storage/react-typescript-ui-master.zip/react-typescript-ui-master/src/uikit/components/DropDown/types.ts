export type TDropDownClasses = {
  dropDown?: string;
  dropDownPanel?: string;
  dropDownButton?: string;
};
