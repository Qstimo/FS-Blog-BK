import type { TAsyncSelectProps } from "uikit";

export type TAutocompleteProps = TAsyncSelectProps;
