export enum EErrorTheme {
  Error = "error",
  Info = "info",
}
