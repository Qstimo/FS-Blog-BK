import { Accept } from "react-dropzone";

export type TUploaderConfig = {
  accept: Accept;
};
