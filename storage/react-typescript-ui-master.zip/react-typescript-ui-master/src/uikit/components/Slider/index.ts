export * from "./SliderArrow";
export * from "./SliderSimple";
export * from "./SliderSyncing";
