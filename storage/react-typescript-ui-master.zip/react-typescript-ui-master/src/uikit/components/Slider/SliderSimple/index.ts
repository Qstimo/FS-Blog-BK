export * from "./settings";
export * from "./SliderSimple";
export * from "./types";
