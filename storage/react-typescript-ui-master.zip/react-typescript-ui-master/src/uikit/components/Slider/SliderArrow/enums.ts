export enum ESliderArrow {
  Next = "next",
  Previous = "previous",
}
