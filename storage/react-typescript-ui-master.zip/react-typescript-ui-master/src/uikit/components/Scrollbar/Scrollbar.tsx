import { Scrollbar } from "smooth-scrollbar-react";

export { Scrollbar };
