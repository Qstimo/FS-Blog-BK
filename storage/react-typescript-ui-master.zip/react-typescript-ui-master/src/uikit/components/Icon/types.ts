import type { ETextColor } from "uikit";

export type TColor = `${ETextColor}` | "inherit";
