export { Icon as default } from "./Icon";
export * from "./Icon";
