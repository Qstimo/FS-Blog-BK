export enum ETooltipBehavior {
  Click = "click",
  Hover = "hover",
}
