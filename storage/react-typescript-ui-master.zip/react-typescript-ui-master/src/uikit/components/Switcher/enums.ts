export enum ESwitcherVariant {
  Default = "Default",
}
