import type { FC } from "react";
import "./Spacer.scss";

export const Spacer: FC = () => <div className="Spacer" />;
