export enum ETablePlacement {
  Top = "top",
  Bottom = "bottom",
}

export enum ETableSortDirection {
  Asc = "ASC",
  Desc = "DESC",
}
