import type { TTableSortingColumnState } from "../types";

export type TSortingColumnStateWithReset = TTableSortingColumnState & { shouldReset?: boolean };
