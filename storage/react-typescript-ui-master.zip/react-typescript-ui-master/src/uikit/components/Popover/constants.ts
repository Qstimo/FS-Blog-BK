export const POPOVER_WIDTH = 512;

export const POPOVER_POSITION_STYLES = {
  left: "left",
  center: "center",
  right: "right",
};
