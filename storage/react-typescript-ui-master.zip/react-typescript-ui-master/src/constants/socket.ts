export const SOCKET_SEND_THEME = "socket_send_theme";
export const SOCKET_RECEIVE_THEME = "socket_receive_theme";
