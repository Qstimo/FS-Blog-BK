export * from "./IconPage";
