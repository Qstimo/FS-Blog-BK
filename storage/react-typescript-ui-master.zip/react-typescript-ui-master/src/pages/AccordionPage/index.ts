export * from "./AccordionPage";
