export * from "./ModalPage";
