export enum ETableColumns {
  Body = "body",
  Id = "id",
  Title = "title",
  UserID = "userId",
}
