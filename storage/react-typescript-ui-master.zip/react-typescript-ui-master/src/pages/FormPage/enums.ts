export enum EFormFields {
  Name = "name",
  Phone = "phone",
  Email = "email",
  Password = "password",
  RePassword = "rePassword",
  Comment = "comment",
}
