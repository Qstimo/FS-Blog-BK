export * from "./TabsPage";
