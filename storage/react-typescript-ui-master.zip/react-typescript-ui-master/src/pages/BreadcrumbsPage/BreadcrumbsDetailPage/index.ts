export * from "./BreadcrumbsDetailPage";
