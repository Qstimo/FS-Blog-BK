export * from "./data";
export * from "./SliderPage";
