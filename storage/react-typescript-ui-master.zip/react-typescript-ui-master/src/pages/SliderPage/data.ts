export const sliderImages = [
  "https://ir.ozone.ru/s3/multimedia-r/wc1000/6377826795.jpg",
  "https://ir.ozone.ru/s3/multimedia-2/wc1000/6327396674.jpg",
  "https://ir.ozone.ru/s3/multimedia-x/wc1000/6377172285.jpg",
  "https://ir.ozone.ru/s3/multimedia-r/wc1000/6618813831.jpg",
  "https://ir.ozone.ru/s3/multimedia-z/wc1000/6595155755.jpg",
  "https://ir.ozone.ru/s3/multimedia-2/wc1000/6531742826.jpg",
];
