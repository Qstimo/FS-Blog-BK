import type { FC } from "react";
import { Title } from "components";

export const PrivateRoutePage: FC = () => {
  return (
    <section>
      <Title>Private Route</Title>
    </section>
  );
};
