export * from "./RatingPage";
