export const formatToCapitalize = (s: string) => {
  return s.charAt(0).toUpperCase() + s.slice(1);
};
