export const PHONE_MASK = "+7 (999) 999 99 99";

export const PAST_BUG_PHONE = "+7 (+7";

export const PAST_BUG_8_PHONE = "+7 (8";
