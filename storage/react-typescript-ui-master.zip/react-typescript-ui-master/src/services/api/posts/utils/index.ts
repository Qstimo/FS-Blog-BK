export * from "./getPostsApi";
