export * from "./mapTableSortingToDto";
