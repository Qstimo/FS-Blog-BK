export type TSearchParams = {
  page: string;
  size: string;
  search?: string;
  sort?: string;
};
