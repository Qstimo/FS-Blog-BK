export type TDeleteModalState = {
  isOpen: boolean;
  alias?: string;
};
