export * from "./ModalDelete";
